import { Tutorial } from './tutorial.model';

describe('Tutorial', () => {
  it('should create an instance', () => {
    expect(new Tutorial()).toBeTruthy();
  });
});
